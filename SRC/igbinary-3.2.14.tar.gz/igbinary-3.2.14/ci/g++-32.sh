#!/bin/sh
exec g++ -m32 "$@"
