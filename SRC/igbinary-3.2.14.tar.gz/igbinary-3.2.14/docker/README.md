Dockerized test scripts
=======================

This uses https://docs.docker.com/desktop/multi-arch/

Currently, this is only used to test locally. See https://github.com/docker/buildx#building-multi-platform-images for installing binfmt with `docker run --privileged`.
